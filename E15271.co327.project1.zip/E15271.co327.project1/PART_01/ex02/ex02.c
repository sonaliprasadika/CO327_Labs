#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>
#include <linux/jiffies.h>
#include <linux/param.h> /*HZ*/

#define BUFFER_SIZE 128
#define PROC_NAME "seconds"

// unsigned long int volatile jstart,jexit;

unsigned long jf,jstart,jexit;

unsigned long hz=HZ;

ssize_t proc_read(struct file *file, char __user *usr_buf, size_t count,loff_t *pos);

static struct file_operations proc_ops = {
   .owner = THIS_MODULE,
   .read = proc_read,
};

int proc_init(void)
{
    proc_create(PROC_NAME,0666,NULL,&proc_ops);
    jstart = jiffies;
    printk(KERN_INFO "seconds loaded!\n");
    printk(KERN_INFO "Start Time : %lu s\n",jstart);
    return 0;
}

void proc_exit(void)
{
    remove_proc_entry(PROC_NAME,NULL);
    // jexit = jiffies;
    printk(KERN_INFO "seconds unloaded!\n");
    // printk(KERN_INFO "No of elapsed seconds since the kernel module was loaded %lu s\n", ((jexit-jstart)/hz));
}


ssize_t proc_read(struct file *file, char __user *usr_buf, size_t count, loff_t *pos)
{
    int rv = 0;
    char buffer[BUFFER_SIZE];
    static int completed = 0;
    if (completed) {
      completed = 0;
      return 0;
    }
    completed = 1;

    jf = jiffies; //Current value of jiffies
    // rv = sprintf(buffer, "The jiffies is %lu\n", jiffies);
    rv = sprintf(buffer, "The jiffies is %lu\n", (jf-jstart)/hz);
    copy_to_user(usr_buf, buffer, rv);
    return rv;
}
module_init(proc_init);
module_exit(proc_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Elapse time");
MODULE_AUTHOR("SONALI");

