#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/types.h>
#include <linux/slab.h>

struct color{

 int red;
 int blue;
 int green;
 struct list_head list; 

};

/*This macro defines and initializes the variable color list, which is of type struct list head.*/
static LIST_HEAD(color_list);

/**
 * This function is called when the module is loaded. 
 *
 * @return 0  upon success
 */ 
int knds_init(void)
{
    printk(KERN_INFO "Loading Kernel Data Structure Module...\n");
    
    struct color *color_element;

    int i;
    for(i=0;i<4;i++){
    	color_element =kmalloc(sizeof(*color_element),GFP_KERNEL);
    	color_element->red = 138+2*i*i;
    	color_element->blue = 43+10*i;
    	color_element->green =226-20*i;
    	/*The macro INIT LIST HEAD() initializes the list member in struct color.*/
    	INIT_LIST_HEAD(&color_element->list);
    	list_add_tail(&color_element->list,&color_list);
    }
    


    struct color *ptr;

    list_for_each_entry(ptr,&color_list,list){
	printk(KERN_INFO "red:- %d blue:- %d green:- %d\n",ptr->red,ptr->blue,ptr->green);
    }

    return 0;
}

/**
 * This function is called when the module is removed.
 *
 * @void
 */
void knds_exit(void)
{
    struct color *ptr,*next;
    list_for_each_entry_safe(ptr,next,&color_list,list){
       list_del(&ptr->list);
       kfree(ptr);
    }
    printk(KERN_INFO "Removing Kernel Data Structure Module...\n");
}


// Macros for registering module entry and exit points.
module_init(knds_init);
module_exit(knds_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Hello Module");
MODULE_AUTHOR("SGG");
