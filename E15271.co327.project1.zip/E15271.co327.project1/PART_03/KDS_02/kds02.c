#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/types.h>
#include <linux/slab.h>
#include<linux/moduleparam.h>

static int start =25;

struct collatz{

 int collatz_no;
 struct list_head list; 

};

module_param(start,int,0);

/*This macro defines and initializes the variable color list, which is of type struct list head.*/
static LIST_HEAD(collatz_list);

/**
 * This function is called when the module is loaded. 
 *
 * @return 0  upon success
 */ 
int knds_init(void)
{
    printk(KERN_INFO "Loading Kernel Data Structure Module...\n");
    
    struct collatz *collatz_element;

    int collatz_val = start;
    if(collatz_val<1){
    	printk(KERN_INFO "Enter valid start number\n");
	return 0;
    }
    while(1){
    	collatz_element =kmalloc(sizeof(*collatz_element),GFP_KERNEL);
    	collatz_element->collatz_no = collatz_val; 
    	/*The macro INIT LIST HEAD() initializes the list member in struct color.*/
    	INIT_LIST_HEAD(&collatz_element->list);
    	list_add_tail(&collatz_element->list,&collatz_list);
	if(collatz_val == 1){
	 	break;
        }
	if(collatz_val % 2 == 0){
		collatz_val = collatz_val/2;
	}else{
		collatz_val = 3*collatz_val +1;
	}
    }
    


    struct collatz *ptr;

    list_for_each_entry(ptr,&collatz_list,list){
	printk(KERN_INFO "collatz-NO:- %d \n",ptr->collatz_no);
    }

    return 0;
}

/**
 * This function is called when the module is removed.
 *
 * @void
 */
void knds_exit(void)
{
    struct collatz *ptr,*next;
    list_for_each_entry_safe(ptr,next,&collatz_list,list){
       list_del(&ptr->list);
       kfree(ptr);
    }
    printk(KERN_INFO "Removing Kernel Data Structure Module...\n");
}


// Macros for registering module entry and exit points.
module_init(knds_init);
module_exit(knds_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Hello Module");
MODULE_AUTHOR("SGG");
